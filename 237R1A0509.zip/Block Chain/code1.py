from datetime import datetime

def parse_time(time_str):
    return datetime.strptime(time_str, "%H:%M")

def detect_conflicts(events):
    conflicts = []
    for i in range(len(events) - 1):
        for j in range(i + 1, len(events)):
            start1, end1 = events[i][1], events[i][2]
            start2, end2 = events[j][1], events[j][2]

            if start2 < end1:
                conflicts.append((events[i][0], events[j][0]))  
    return conflicts

def suggest_resolutions(conflicts):
    resolutions = []
    
    for event1, event2 in conflicts:
        if event2 == "Workshop B":
            resolutions.append((event2, "13:00", "14:30")) 
    
    return resolutions

events = [
    ("Meeting A", "09:00", "10:30"),
    ("Workshop B", "10:00", "11:30"),
    ("Presentation C", "10:30", "12:00"),
    ("Lunch Break", "12:00", "13:00"),
]

events = [(desc, parse_time(start), parse_time(end)) for desc, start, end in events]

events.sort(key=lambda x: x[1])

conflicts = detect_conflicts(events)

resolutions = suggest_resolutions(conflicts)

print("Sorted Schedule:")
for i, event in enumerate(events, 1):
    print(f'{i}. "{event[0]}", Start: "{event[1].strftime("%H:%M")}", End: "{event[2].strftime("%H:%M")}"')

print("\nConflicting Events:")
for i, conflict in enumerate(conflicts, 1):
    print(f'{i}. "{conflict[0]}" and "{conflict[1]}"')

print("\nSuggested Resolutions:")
for i, (event, new_start, new_end) in enumerate(resolutions, 1):
    print(f'{i}. Reschedule "{event}" to Start: "{new_start}", End: "{new_end}"')