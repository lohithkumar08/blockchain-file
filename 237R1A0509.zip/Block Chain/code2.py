from typing import List, Tuple, Dict
from dataclasses import dataclass
from collections import defaultdict
import math

@dataclass
class DeliveryPoint:
    id: str
    x: float
    y: float
    priority: str  # 'high', 'medium', 'low'
    sequence: int  # original order in input

    def to_tuple(self) -> Tuple[float, float]:
        return (self.x, self.y)

class DeliveryRouteOptimizer:
    def __init__(self):
        self.priority_order = {
            'high': 0,
            'medium': 1,
            'low': 2
        }
    
    def calculate_distance(self, point1: DeliveryPoint, point2: DeliveryPoint) -> float:
        """Calculate Euclidean distance between two delivery points."""
        return math.sqrt((point2.x - point1.x)**2 + (point2.y - point1.y)**2)
    
    def calculate_total_distance(self, route: List[DeliveryPoint]) -> float:
        """Calculate total distance of the route including return to depot."""
        if not route:
            return 0.0
            
        total_distance = 0.0
        # Distance from depot to first point
        total_distance += math.sqrt(route[0].x**2 + route[0].y**2)
        
        # Distance between consecutive points
        for i in range(len(route) - 1):
            total_distance += self.calculate_distance(route[i], route[i + 1])
            
        # Distance from last point back to depot
        last_point = route[-1]
        total_distance += math.sqrt(last_point.x**2 + last_point.y**2)
        
        return total_distance
    
    def group_by_priority(self, delivery_points: List[DeliveryPoint]) -> Dict[str, List[DeliveryPoint]]:
        """Group delivery points by priority level."""
        priority_groups = defaultdict(list)
        for point in delivery_points:
            priority_groups[point.priority].append(point)
        return priority_groups
    
    def optimize_route_within_priority(self, points: List[DeliveryPoint], start_point: DeliveryPoint) -> List[DeliveryPoint]:
        """
        Optimize route within a priority group using nearest neighbor approach.
        Maintains original sequence for equal distances.
        """
        if not points:
            return []
            
        unvisited = points.copy()
        route = []
        current_point = start_point
        
        while unvisited:
            distances = [(self.calculate_distance(current_point, point), point) for point in unvisited]
            distances.sort(key=lambda x: (x[0], x[1].sequence))
            current_point = distances[0][1]
            route.append(current_point)
            unvisited.remove(current_point)
            
        return route
    
    def optimize_route(self, delivery_points: List[DeliveryPoint], depot: Tuple[float, float] = (0, 0)) -> List[DeliveryPoint]:
        """Generate optimized delivery route considering priorities and distances."""
        if not delivery_points:
            return []
        
        depot_point = DeliveryPoint(id='depot', x=depot[0], y=depot[1], priority='high', sequence=-1)
        priority_groups = self.group_by_priority(delivery_points)
        optimized_route = []
        current_point = depot_point
        
        for priority in ['high', 'medium', 'low']:
            if priority in priority_groups:
                priority_route = self.optimize_route_within_priority(
                    priority_groups[priority],
                    current_point
                )
                optimized_route.extend(priority_route)
                if priority_route:
                    current_point = priority_route[-1]
        
        return optimized_route

def format_route_coordinates(route: List[DeliveryPoint], depot: Tuple[float, float] = (0, 0)) -> str:
    """Format route as list of coordinates including depot."""
    coordinates = [depot]  # Start at depot
    coordinates.extend(point.to_tuple() for point in route)
    coordinates.append(depot)  # Return to depot
    return f"Optimized Route: {coordinates}"

# Example usage
def main():
    # Create sample delivery points
    delivery_points = [
        DeliveryPoint("A", 5.0, 1.0, "high", 0),
        DeliveryPoint("B", 2.0, 3.0, "high", 1),
        DeliveryPoint("C", 1.0, 2.0, "medium", 2),
        DeliveryPoint("D", 6.0, 4.0, "low", 3),
    ]
    
    # Create optimizer and generate route
    optimizer = DeliveryRouteOptimizer()
    optimized_route = optimizer.optimize_route(delivery_points)
    
    # Calculate total distance
    total_distance = optimizer.calculate_total_distance(optimized_route)
    
    # Print results in requested format
    print(format_route_coordinates(optimized_route))
    print(f"Total Distance: {total_distance:.2f} units")

if __name__ == "__main__":
    main()